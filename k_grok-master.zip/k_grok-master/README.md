# k_grok
Exercises to help grok the Linux kernel

This material is on the course [Open Source
Programming](https://sites.google.com/a/ucsc.edu/open-source-programming)
delivered to UC Santa Cruz in Winter 2016. While the course material involved
step-by-step instructions given in Google Doc formats, this material is
intended to be executable.
